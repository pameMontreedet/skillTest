#!/usr/bin/env bash
dotnet build
dotnet watch run --environment="Development"  