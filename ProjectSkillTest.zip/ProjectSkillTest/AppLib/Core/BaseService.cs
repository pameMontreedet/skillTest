using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace AppLib.Core {
    
    public abstract class BaseService {
        
    }
}