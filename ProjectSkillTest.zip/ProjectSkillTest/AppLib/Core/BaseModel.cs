using System;

namespace AppLib.Core {
    public abstract class BaseModel {
        
    }
}