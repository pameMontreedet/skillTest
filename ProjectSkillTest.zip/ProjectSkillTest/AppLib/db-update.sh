#!/usr/bin/env bash

dotnet ef --startup-project ../AppBackend/ database update