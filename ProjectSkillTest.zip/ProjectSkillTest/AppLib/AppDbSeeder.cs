using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace AppLib
{
    public class AppDbSeeder
    {
        public static void Seed(AppDbContext context)
        {
               
        }
    }
}